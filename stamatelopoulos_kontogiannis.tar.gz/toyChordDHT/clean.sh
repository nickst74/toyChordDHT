#!/bin/bash

rm -r ./target/*