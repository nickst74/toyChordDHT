#!/bin/bash

java -cp ./target/toyChord.jar toyChord.supplementary.Deletions
