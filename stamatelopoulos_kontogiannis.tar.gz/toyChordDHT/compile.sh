#!/bin/bash

cd src
make
echo "Compile finished."