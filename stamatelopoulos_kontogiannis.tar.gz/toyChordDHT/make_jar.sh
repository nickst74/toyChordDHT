#/bin/bash

cd target/
jar cfev toyChord.jar . ./toyChord/*