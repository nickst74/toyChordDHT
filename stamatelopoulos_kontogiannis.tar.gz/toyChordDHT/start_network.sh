#!/bin/bash

java -cp ./target/toyChord.jar toyChord.Node $1
